package com.example.adventure_game

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
