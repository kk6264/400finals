import 'dart:io';
import 'package:restart_app/restart_app.dart';
import 'package:flutter/material.dart';

void main() => runApp(MaterialApp(
  title: 'Choose Your Adventure Game',
  home: AdventureGame(),
));

class AdventureGame extends StatefulWidget {
  @override
  _AdventureGameState createState() => _AdventureGameState();
}

class _AdventureGameState extends State<AdventureGame> {
  int _currentStep = 0;
  int _itemCount = 0;
  String _location0 = "Entrance";
  String _location1 = "Foyer";
  String _location2 = "Room 1";
  String _location3 = "Room 2";
  String _location4 = "Room 3";
  String _location5 = "Room 4";
  String _location6 = "Room 5";
  String _location7 = "Secret Exit";
  String _takeItem = "Yes";
  String _ignoreItem = "Leave room";
  bool _room1Taken = false;
  bool _room2Taken = false;
  bool _room3Taken = false;
  bool _room4Taken = false;
  bool _room5Taken = false;

  void _selectOption(int option) {
    setState(() {
      _currentStep = option;
    });
  }

  void _selectItem(int counter) {
    setState(() {
      _itemCount = counter;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Finals Foyer - Adventure Game'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            //LOCATION - ENTRANCE
            SizedBox(height: 20),
              Text(
                // SITUATIONAL DESCRIPTIONS
                _currentStep == 0
                  ? 'This is the $_location0 to Finals Foyer.\nProceed forward into the foyer.'
                  : _currentStep == 1
                  ? 'Welcome to Finals Foyer.'
                  : 'Collect items to beat the game.',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              // CONTROLS - ENTRANCE
              SizedBox(height: 20),
                Image.asset('assets/images/entrance.jpg'),
                Text(
                  'Currently in position [$_currentStep]\nItems held: [$_itemCount]',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.red),
               ),
            _currentStep == 0
                // CONTROLS - ENTRANCE
                ? Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    ElevatedButton(
                      onPressed: () {
                        _selectOption(_currentStep = 1);
                      },
                      child: Text('Enter Finals Foyer'),
                    ),
                  ],
                )
              : SizedBox(),

            // LOCATION - FOYER
            // Image.asset('assets/images/0.jpg'),
            _currentStep == 1
            // CONTROLS - FOYER - ROW 1
                ? Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    if (_room1Taken == false)
                      ElevatedButton(
                        onPressed: () {
                          _selectOption(_currentStep = 2);
                        },
                        child: Text('$_location2'),
                      ),

                    if (_room2Taken == false)
                    ElevatedButton(
                      onPressed: () {
                        _selectOption(_currentStep = 3);
                      },
                      child: Text('$_location3'),
                    ),

                    if (_room3Taken == false)
                    ElevatedButton(
                      onPressed: () {
                        _selectOption(_currentStep = 4);
                      },
                      child: Text('$_location4'),
                    ),
                  ],
                )
            : SizedBox(),
            // CONTROLS - FOYER - ROW 2
            SizedBox(height: 20),
            _currentStep == 1
                ? Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    if (_room4Taken == false)
                    ElevatedButton(
                      onPressed: () {
                        _selectOption(_currentStep = 5);
                      },
                      child: Text('$_location5'),
                    ),

                    if (_room5Taken == false)
                    ElevatedButton(
                      onPressed: () {
                        _selectOption(_currentStep = 6);
                      },
                      child: Text('$_location6'),
                    ),

                    if (_itemCount > 3)
                      ElevatedButton(
                        onPressed: () {
                          _selectOption(_currentStep = 7);
                        },
                        child: Text('$_location7'),
                      ),
                  ],
                )
                : SizedBox(),

            // LOCATION - ROOM 1
            // Image.asset('assets/images/1.jpg'),
            _currentStep == 2
            // CONTROLS - ROOM 1
                ? Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      Text(
                        'There is a [[broom]] on the floor.\nDo you pick it up?',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black),
                      ),
                    ],
                )

                : SizedBox(),

            _currentStep == 2
                ? Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    ElevatedButton(
                      onPressed: () {
                        _selectItem(_itemCount += 1);
                        _selectOption(_currentStep = 1);
                        _room1Taken = true;
                      },
                      child: Text('$_takeItem'),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        _selectItem(_itemCount);
                        _selectOption(_currentStep = 1);
                      },
                      child: Text('$_ignoreItem'),
                    ),
                  ],
                )
                : SizedBox(),

            // LOCATION - ROOM 2
            // Image.asset('assets/images/2.jpg'),
            _currentStep == 3
            // CONTROLS - ROOM 2
                ? Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      Text(
                        'There is a [[match]] on the floor.\nDo you pick it up?',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black),
                      ),
                    ],
                  )

                : SizedBox(),

            _currentStep == 3
                ? Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    ElevatedButton(
                      onPressed: () {
                        _selectItem(_itemCount += 1);
                        _selectOption(_currentStep = 1);
                        _room2Taken = true;
                      },
                      child: Text('$_takeItem'),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        _selectItem(_itemCount);
                        _selectOption(_currentStep = 1);
                      },
                      child: Text('$_ignoreItem'),
                    ),
                  ],
                )
                : SizedBox(),

            // LOCATION - ROOM 3
            // Image.asset('assets/images/3.jpg'),
            _currentStep == 4
            // CONTROLS - ROOM 3
                ? Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Text(
                      'There is a [[turkey]] on the floor.\nDo you pick it up?',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black),
                    ),
                  ],
                )

                : SizedBox(),

            _currentStep == 4
                ? Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                ElevatedButton(
                  onPressed: () {
                    _selectItem(_itemCount += 1);
                    _selectOption(_currentStep = 1);
                    _room3Taken = true;
                  },
                  child: Text('$_takeItem'),
                ),
                ElevatedButton(
                  onPressed: () {
                    _selectItem(_itemCount);
                    _selectOption(_currentStep = 1);
                  },
                  child: Text('$_ignoreItem'),
                ),
              ],
            )
                : SizedBox(),

            // LOCATION - ROOM 4
            // Image.asset('assets/images/4.jpg'),
            _currentStep == 5
            // CONTROLS - ROOM 4
                  ? Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      Text(
                        'You fell down a trapdoor.\nGAME OVER.',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black),
                      ),
                    ],
                  )
                : SizedBox(),

            _currentStep == 5
                ? Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      ElevatedButton(
                        onPressed: () {
                          _selectItem(_itemCount);
                          _selectOption(_currentStep = 1);
                          _room4Taken = true;
                        },
                        child: Text('Escape'),
                      ),
                    ],
                  )

                : SizedBox(),


            // LOCATION - ROOM 5
            // Image.asset('assets/images/5.jpg'),
            _currentStep == 6
            // CONTROLS - ROOM 5
                ? Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Text(
                      'There is a [[sponge]] on the floor.\nDo you pick it up?',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black),
                    ),
                  ],
                )
                : SizedBox(),

            _currentStep == 6
                ? Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                ElevatedButton(
                  onPressed: () {
                    _selectItem(_itemCount += 1);
                    _selectOption(_currentStep = 1);
                    _room5Taken = true;
                  },
                  child: Text('$_takeItem'),
                ),
                ElevatedButton(
                  onPressed: () {
                    _selectItem(_itemCount);
                    _selectOption(_currentStep = 1);
                  },
                  child: Text('$_ignoreItem'),
                ),
              ],
            )
                : SizedBox(),

            // LOCATION - EXIT ROOM
            // Image.asset('assets/images/6.jpg'),
            _currentStep == 7
            // CONTROLS - ROOM 6
                ? Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      Text(
                        'YOU WIN THE GAME!\nTHANK YOU FOR AN AWESOME QUARTER!',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black),
                      ),
                    ],
                  )
                : SizedBox(),

            // RESET GAME/EXIT GAME ROW
            SizedBox(height: 20),
            _currentStep >= 0
                ? Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                ElevatedButton(
                  onPressed: () {
                    Restart.restartApp();
                  },
                  child: Text('Restart from Entrance'),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.pink),
                ),
                ElevatedButton(
                  onPressed: () {
                    _selectOption(_currentStep = 1);
                  },
                  child: Text('Foyer'),
                ),
                ElevatedButton(
                  onPressed: () {
                    _selectOption(exit(0));
                  },
                  child: Text('Exit Game'),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                ),
              ],
            )

          : SizedBox(), // End of overarching sizedbox
          ],
        ),
      ),
    );
  }
}
